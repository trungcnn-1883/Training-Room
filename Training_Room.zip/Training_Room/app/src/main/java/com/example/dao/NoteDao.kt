package com.example.dao

import androidx.room.Dao
import androidx.room.Delete
import androidx.room.Insert
import androidx.room.Query
import com.example.entity.Note

@Dao
interface NoteDao {

    @Query("SELECT * FROM note")
    fun getAllNotes(): List<Note>

    @Insert
    fun addNote(note: Note)

    @Delete
    fun deleteNode(note: Note)

    @Query("SELECT COUNT(id) FROM note")
    fun getNoteCount(): Int

}