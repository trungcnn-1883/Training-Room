package com.example.database

import androidx.room.Database
import androidx.room.RoomDatabase
import com.example.dao.NoteDao
import com.example.entity.Note

@Database(entities = arrayOf(Note::class), version = 1)
abstract class MyDataBaseHelper() : RoomDatabase() {

    abstract fun noteDao(): NoteDao

}