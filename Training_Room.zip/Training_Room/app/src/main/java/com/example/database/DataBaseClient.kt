package com.example.database

import android.content.Context
import androidx.room.Room


class DataBaseClient {

    var mContext: Context? = null


    companion object {

        private var mInstance: MyDataBaseHelper? = null
        private lateinit var mMyDataBaseHelper: MyDataBaseHelper


        @Synchronized
        fun getMyDataBaseHelper(mContext: Context): MyDataBaseHelper {
            if (mInstance == null) {
                mInstance = Room.databaseBuilder(mContext, MyDataBaseHelper::class.java!!, "MyToDos").build()
            }
            return mInstance as MyDataBaseHelper
        }
    }


}